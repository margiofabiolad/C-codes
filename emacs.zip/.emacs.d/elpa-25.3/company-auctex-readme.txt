To use:
(require 'company-auctex)
(company-auctex-init)
Feel free to contribute better documentation!
